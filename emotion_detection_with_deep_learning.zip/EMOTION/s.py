from flask import Flask, render_template, request, jsonify
from keras.models import model_from_json
from keras.preprocessing import image
import numpy as np
import cv2
import base64

app = Flask(__name__)

# Load the model architecture from JSON file
with open('emotiondetector.json', 'r') as json_file:
    model_json = json_file.read()
    loaded_model = model_from_json(model_json)

# Load the model weights
loaded_model.load_weights('emotiondetector.h5')

# Function to preprocess the base64 image data for model prediction
def preprocess_image(img_data):
    img_data = base64.b64decode(img_data.split(',')[1])
    img_array = np.frombuffer(img_data, np.uint8)
    img = cv2.imdecode(img_array, cv2.IMREAD_GRAYSCALE)
    img = cv2.resize(img, (48, 48))
    img = np.expand_dims(img, axis=0)
    img = img / 255.0  # Normalize pixel values
    return img

@app.route('/')
def home():
    return render_template('ede.html')

@app.route('/detect', methods=['POST'])
def detect_emotion():
    if request.method == 'POST':
        # Get the base64-encoded image data from the request
        img_data = request.json['image']
        # Preprocess the image
        img_data = preprocess_image(img_data)
        print("Input image shape:", img_data.shape)  # Debugging
        # Make prediction using the loaded model
        prediction = loaded_model.predict(img_data)
        print("Raw prediction:", prediction)  # Debugging
        # Decode the prediction (assuming one-hot encoded labels)
        predicted_emotion = np.argmax(prediction)
        # Map the predicted emotion to a human-readable label
        emotion_labels = ['Angry', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']
        emotion = emotion_labels[predicted_emotion]
        print("Predicted emotion:", emotion)  # Debugging
        # Return the predicted emotion as JSON response
        return jsonify({'emotion': emotion})
    else:
        return jsonify({'error': 'Invalid request method'})

if __name__ == '__main__':
    app.run(debug=True)
