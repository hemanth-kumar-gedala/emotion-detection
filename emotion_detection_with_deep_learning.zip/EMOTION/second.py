from flask import Flask, render_template, request, jsonify
from keras.models import load_model
import cv2
import numpy as np
import base64

app = Flask(__name__)
model = load_model('emotionmay.h5')  # Load the trained model

# Function to preprocess the base64 image data for model prediction
def preprocess_image(img_data):
    img_data = base64.b64decode(img_data.split(',')[1])
    img_array = np.frombuffer(img_data, np.uint8)
    img = cv2.imdecode(img_array, cv2.IMREAD_GRAYSCALE)
    img = cv2.resize(img, (48, 48))
    img = np.expand_dims(img, axis=-1)  # Add channel dimension
    img = np.expand_dims(img, axis=0)
    img = img / 255.0  # Normalize pixel values
    return img

@app.route('/')
def home():
    return render_template('edho.html')

@app.route('/detect_emotion', methods=['POST'])
def detect_emotion():
    if request.method == 'POST':
        # Get the base64-encoded image data from the request
        img_data = request.json['image']
        # Preprocess the image
        img_data = preprocess_image(img_data)
        # Make prediction using the loaded model
        prediction = model.predict(img_data)
        # Decode the prediction (assuming one-hot encoded labels)
        predicted_emotion = np.argmax(prediction)
        # Map the predicted emotion to a human-readable label
        emotion_labels = ['Angry', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']
        emotion = emotion_labels[predicted_emotion]
        # Return the predicted emotion as JSON response
        return jsonify({'emotion': emotion})
    else:
        return jsonify({'error': 'Invalid request method'})

if __name__ == '__main__':
    app.run(debug=True)
