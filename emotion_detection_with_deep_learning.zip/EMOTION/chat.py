from flask import Flask, request, render_template, redirect, url_for
import tensorflow as tf
from tensorflow.keras.models import load_model
import numpy as np
import cv2

# Initialize Flask app
app = Flask(__name__)

# Load the trained model
model_path = 'emotion_detection_model_corrected112.keras'
model = load_model(model_path)

# Define emotion labels
emotion_labels = {0: 'Angry', 1: 'Disgust', 2: 'Happy', 3: 'Sad', 4: 'Surprise', 5: 'Neutral', 6: 'Fear'}

# Load pre-trained face detector
haarcascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
face_cascade = cv2.CascadeClassifier(haarcascade_path)

# Function to preprocess uploaded image
def preprocess_image(image):
    img_array = np.frombuffer(image, np.uint8)
    img = cv2.imdecode(img_array, cv2.IMREAD_GRAYSCALE)
    faces = face_cascade.detectMultiScale(img, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
    
    if len(faces) == 0:
        return None, None
    
    # Assuming the first detected face is the one we want to process
    (x, y, w, h) = faces[0]
    face = img[y:y+h, x:x+w]
    face = cv2.resize(face, (150, 150))
    face = face / 255.0  # Normalize to [0, 1]
    return face, (x, y, w, h)

# Define route for home page
@app.route('/')
def home():
    return render_template('index.html')
@app.route('/neutralmusic')
def neutralmusic():
    return render_template('neutralmusic.html')

@app.route('/sadmusic')
def sadmusic():
    return render_template('sadmusic.html')
@app.route('/happymusic')
def happymusic():
    return render_template('happymusic.html')
@app.route('/angrymusic')
def angrymusic():
    return render_template('angrymusic.html')
@app.route('/surprisemusic')
def surprisemusic():
    return render_template('surprisemusic.html')
@app.route('/fearmusic')
def fearmusic():
    return render_template('fearmusic.html')
@app.route('/disguistmusic')
def disguistmusic():
    return render_template('disguistmusic.html')

# Define route for prediction
@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        file = request.files['image']
        
        if not file:
            return render_template('index.html', prediction="No file uploaded")

        try:
            img, face_coords = preprocess_image(file.read())
            if img is None:
                return render_template('index.html', prediction="No face detected")

            img = np.expand_dims(img, axis=0)  # Expand dimensions to match model input
            
            # Make prediction
            prediction = model.predict(img)
            predicted_label = emotion_labels[np.argmax(prediction)]

            # Redirect to specific emotion page
            return redirect(url_for(predicted_label.lower()))

        except Exception as e:
            print(f"Error during prediction: {e}")
            return render_template('index.html', prediction="Error processing image")

# Define routes for each emotion
@app.route('/happy')
def happy():
    return render_template('happy.html')

@app.route('/sad')
def sad():
    return render_template('sad.html')

@app.route('/angry')
def angry():
    return render_template('angry.html')

@app.route('/disgust')
def disgust():
    return render_template('disguist.html')

@app.route('/surprise')
def surprise():
    return render_template('surprise.html')

@app.route('/neutral')
def neutral():
    return render_template('neutral.html')

@app.route('/fear')
def fear():
    return render_template('fear.html')

if __name__ == '__main__':
    app.run(debug=True)
