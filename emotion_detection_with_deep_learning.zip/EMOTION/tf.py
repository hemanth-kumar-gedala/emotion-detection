import tensorflow as tf
print(tf.__version__)

import tensorflow.keras as keras
print(keras.__version__)
