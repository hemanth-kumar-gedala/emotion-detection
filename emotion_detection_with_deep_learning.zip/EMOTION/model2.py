import numpy as np
import cv2
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from keras.preprocessing.image import ImageDataGenerator

# Define constants
input_shape = (48, 48, 1)  # Input image dimensions (grayscale)
num_classes = 7  # Number of emotion classes
batch_size = 32
epochs = 20

# Load and preprocess your dataset
def preprocess_image(image_path):
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    img = cv2.resize(img, (input_shape[0], input_shape[1]))
    img = img.reshape(input_shape)
    img = img.astype('float32') / 255.0  # Normalize pixel values
    return img

# Load your dataset and preprocess images
def load_dataset(dataset_path):
    data = []
    labels = []
    for emotion_label in os.listdir(dataset_path):
        for image_name in os.listdir(os.path.join(dataset_path, emotion_label)):
            image_path = os.path.join(dataset_path, emotion_label, image_name)
            img = preprocess_image(image_path)
            data.append(img)
            labels.append(emotion_label)
    return np.array(data), np.array(labels)

# Assuming you have a dataset directory structure like:
# dataset/
# ├── angry/
# ├── disgust/
# ├── fear/
# ├── happy/
# ├── neutral/
# ├── sad/
# └── surprise/
dataset_path = 'images/train'
data, labels = load_dataset(dataset_path)

# Convert labels to one-hot encoding
from sklearn.preprocessing import LabelEncoder
from keras.utils import to_categorical

label_encoder = LabelEncoder()
encoded_labels = label_encoder.fit_transform(labels)
one_hot_labels = to_categorical(encoded_labels, num_classes=num_classes)

# Split data into training and validation sets
from sklearn.model_selection import train_test_split

x_train, x_val, y_train, y_val = train_test_split(data, one_hot_labels, test_size=0.2, random_state=42)

# Data augmentation
train_data_gen = ImageDataGenerator(
    rotation_range=15,
    width_shift_range=0.1,
    height_shift_range=0.1,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True
)

train_generator = train_data_gen.flow(x_train, y_train, batch_size=batch_size)

# Define the CNN model
model = Sequential()
model.add(Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=input_shape))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))

model.add(Conv2D(64, kernel_size=(3, 3), activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))

model.add(Flatten())
model.add(Dense(128, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(num_classes, activation='softmax'))

model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

# Train the model
model.fit(
    train_generator,
    steps_per_epoch=len(x_train) // batch_size,
    epochs=epochs,
    validation_data=(x_val, y_val)
)

# Save the trained model
model.save('emotionmay.h5')
